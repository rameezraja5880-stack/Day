import { createRoot } from "react-dom/client";
import { RouterProvider, createRouter, createHashHistory } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";
import "./styles.css";
const router = createRouter({ routeTree, history: createHashHistory(), scrollRestoration: true, defaultPreloadStaleTime: 0 });
createRoot(document.getElementById("root")!).render(<RouterProvider router={router} />);
