import { Outlet, createRootRoute } from "@tanstack/react-router";
import { Nav } from "@/components/scrap";
export const Route = createRootRoute({
  component: () => (
    <>
      <Nav />
      <Outlet />
      <footer className="pb-8 text-center font-hand text-xl text-muted-foreground">made at 2 AM with love, memes &amp; stardust — YOUR SSD ♡</footer>
    </>
  ),
});
