import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CONFIG } from "@/config";
import { Doodles, Heading, Meme, NextButton, Page } from "@/components/scrap";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "The Birthday Incident — Zama Zargi" },
      { name: "description", content: "Urgent internet news: Amy has officially turned 24." },
      { property: "og:title", content: "The Birthday Incident — Zama Zargi" },
      { property: "og:description", content: "Urgent internet news: Amy has officially turned 24." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const STICKERS = [
  { icon: "⭐", x: "6%", y: "12%" },
  { icon: "🐾", x: "88%", y: "8%" },
  { icon: "⭐", x: "92%", y: "62%" },
  { icon: "🐾", x: "4%", y: "70%" },
  { icon: "⭐", x: "48%", y: "2%" },
];

function Home() {
  const [open, setOpen] = useState<number | null>(null);
  const rows = [
    ["SUBJECT", `${CONFIG.fullName.toUpperCase()} / ${CONFIG.name.toUpperCase()}`],
    ["AGE UPDATE", String(CONFIG.age)],
    ["KNOWN HABITATS", "Planet Earth, the internet, and somewhere among the stars"],
    ["KNOWN WEAKNESSES", "Cats, space facts, and questionable memes"],
    ["THREAT LEVEL", "Extremely iconic"],
  ];
  return (
    <Page>
      <section className="relative overflow-hidden rounded-[28px] border-2 border-ink bg-card px-4 py-12 sm:px-10" style={{ boxShadow: "var(--shadow-sticker)" }}>
        <Doodles count={18} seed={2} />
        <div aria-hidden className="absolute -left-10 top-24 h-40 w-40 rotate-12 rounded-[40%_60%_50%_50%] bg-sky/60" />
        <div aria-hidden className="absolute -right-8 bottom-10 h-52 w-52 -rotate-6 rounded-[60%_40%_55%_45%] bg-sage/50" />
        {STICKERS.map((s, i) => (
          <button key={i} onClick={() => setOpen(open === i ? null : i)} aria-label={`Secret sticker ${i + 1}`} className="absolute z-20 text-3xl transition hover:scale-125" style={{ left: s.x, top: s.y }}>
            {s.icon}
          </button>
        ))}
        {open !== null && (
          <div role="status" className="pop-in bubble absolute left-1/2 top-16 z-30 w-72 -translate-x-1/2 text-center bg-butter">
            {CONFIG.homeSecrets[open]}
            <button onClick={() => setOpen(null)} className="ml-2 font-display text-sm underline">close</button>
          </div>
        )}

        <div className="relative z-10">
          <Heading kicker="URGENT INTERNET NEWS 🚨" title={`${CONFIG.name.toUpperCase()} HAS OFFICIALLY TURNED ${CONFIG.age}.`} sub="Authorities have confirmed that she is still obsessed with cats and the universe." />

          <div className="mt-10 grid items-center gap-8 md:grid-cols-[1fr_1.2fr_1fr]">
            <Meme kind="sleepy" caption={CONFIG.captions.homeSleepy} size={210} rotate={-4} className="floaty" />
            <article className="relative scrap-card rotate-1 p-5 font-mono text-sm">
              <span className="tape -top-3 left-1/2 -translate-x-1/2 -rotate-3" />
              <h2 className="mb-3 border-b-2 border-dashed border-ink pb-2 font-display text-lg font-bold">📰 OFFICIAL FILE · BREAKING</h2>
              <dl className="space-y-2">
                {rows.map(([k, v]) => (
                  <div key={k} className="grid grid-cols-[8.5rem_1fr] gap-2">
                    <dt className="font-bold">{k}:</dt><dd>{v}</dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 font-hand text-lg text-muted-foreground">*entirely fictional & unserious report</p>
            </article>
            <Meme kind="heart" caption={CONFIG.captions.homeHeart} size={180} rotate={5} bubbleSide="bottom" />
          </div>
          <p className="mt-8 text-center font-hand text-xl text-muted-foreground">psst… tap the stars & paw prints ⭐🐾</p>
        </div>
      </section>
      <NextButton to="/universe" turn>OKAY FINE, SHOW ME MY WEBSITE →</NextButton>
    </Page>
  );
}
