import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { CONFIG, pick } from "@/config";
import { Doodles, Heading, Meme, NextButton, Page, SectionTitle } from "@/components/scrap";
import { MemeExhibits } from "@/components/meme-exhibits";
import { keepScrapbookEntry } from "@/lib/scrapbook";
import thinkingCat from "@/assets/cat-cat_thinking.jpg";

export const Route = createFileRoute("/twins")({
  head: () => ({
    meta: [
      { title: "Twin Behavior Evidence — Zama Zargi" },
      { name: "description", content: "Case file: two weirdos, one friendship. Investigating suspicious levels of twin energy." },
      { property: "og:title", content: "Twin Behavior Evidence — Zama Zargi" },
      { property: "og:description", content: "Case file: two weirdos, one friendship." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Twins,
});

function Twins() {
  return (
    <Page>
      <section className="relative">
        <Doodles count={14} seed={7} />
        <Heading kicker="📁 CLASSIFIED (not really)" title="CASE FILE: TWO WEIRDOS, ONE FRIENDSHIP." sub="Investigating the suspicious levels of twin energy." />
      </section>

      <SectionTitle note="pinned with red string, probably">The evidence board</SectionTitle>
      <div className="grid gap-6 rounded-3xl border-2 border-ink bg-rose/25 p-6 sm:grid-cols-2">
        {CONFIG.evidence.map((e, i) => (
          <article key={i} className="relative scrap-card p-5" style={{ transform: `rotate(${[-1.5, 1, 1.5, -1][i]}deg)` }}>
            <span aria-hidden className="absolute -top-4 left-5 text-3xl">📎</span>
            <p className="font-display text-xs font-bold tracking-widest text-muted-foreground">EXHIBIT {"ABCD"[i]}</p>
            <h3 className="text-xl font-bold">{e.title}</h3>
            <p className="mt-2 font-hand text-2xl leading-tight">{e.caption}</p>
            <span aria-hidden className="absolute bottom-2 right-3 text-2xl opacity-40">{["🫆", "✦", "♡", "☆"][i]}</span>
          </article>
        ))}
      </div>

      <SectionTitle note="results scientifically unverified">Twin energy calculator</SectionTitle>
      <TwinCalc />

      <SectionTitle note="click to reveal">Friendship awards</SectionTitle>
      <Awards />

      <SectionTitle note="for us to fill in later">The memory scrapbook</SectionTitle>
      <Memories />

      <SectionTitle>The meme evidence nobody asked for</SectionTitle>
      <MemeExhibits />

      <section className="mx-auto mt-20 flex max-w-xl flex-col items-center gap-4 rounded-3xl bg-sage/30 p-10 text-center">
        <Meme kind="heart" size={170} />
        <p className="font-hand text-4xl">{CONFIG.captions.twinHeart}</p>
      </section>

      <NextButton to="/letter">ONE FINAL PAGE. DO NOT GET EMOTIONAL YET →</NextButton>
    </Page>
  );
}

function TwinCalc() {
  const [phase, setPhase] = useState<"idle" | "loading" | "done">("idle");
  const [step, setStep] = useState(0);
  const [result, setResult] = useState("");
  const t = useRef<number | null>(null);
  useEffect(() => () => { if (t.current) clearInterval(t.current); }, []);
  const finish = () => { if (t.current) clearInterval(t.current); setResult((r) => pick(CONFIG.twinResults, r)); setPhase("done"); };
  const start = () => {
    setPhase("loading"); setStep(0);
    let s = 0;
    t.current = window.setInterval(() => { s++; if (s >= CONFIG.twinLoading.length) finish(); else setStep(s); }, 700);
  };
  return (
    <div className="scrap-card grid items-center gap-6 bg-sky/25 p-6 md:grid-cols-[auto_1fr]">
      <div className="relative mx-auto h-40 w-40" aria-hidden>
        <div className="absolute inset-6 rounded-full border-2 border-dashed border-ink/40" />
        <div className={`absolute inset-0 ${phase === "loading" ? "orbit" : ""}`}>
          <span className="absolute left-1/2 top-2 -translate-x-1/2 text-4xl">⭐</span>
          <span className="absolute bottom-2 left-1/2 -translate-x-1/2 text-4xl">🌟</span>
        </div>
        <span className="absolute inset-0 grid place-items-center font-hand text-xl">you + me</span>
      </div>
      <div className="text-center md:text-left" aria-live="polite">
        {phase === "loading" ? (
          <>
            <img src={thinkingCat.url} alt="Cat calculating with math equations behind it" className="pop-in mb-3 w-full max-w-md rounded-lg border-2 border-ink" />
            <p className="font-hand text-3xl">{CONFIG.twinLoading[step]}</p>
            <button onClick={finish} className="mt-3 text-sm font-display underline">skip →</button>
          </>
        ) : (
          <>
            {phase === "done" && <p key={result} className="pop-in mb-4 font-hand text-3xl">{result}</p>}
            <button className="btn-scrap" onClick={start}>{phase === "done" ? "RECALCULATE" : "CALCULATE OUR TWIN ENERGY"}</button>
          </>
        )}
      </div>
    </div>
  );
}

function Awards() {
  const [flipped, setFlipped] = useState<Record<number, boolean>>({});
  const colors = ["bg-butter", "bg-rose/60", "bg-sky/60", "bg-sage/60", "bg-lavender/60"];
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
      {CONFIG.awards.map((a, i) => (
        <button key={i} onClick={() => setFlipped((f) => ({ ...f, [i]: !f[i] }))} aria-pressed={!!flipped[i]} aria-label={`${a.title}. ${flipped[i] ? a.hidden : "Click to reveal"}`} className="flip-wrap h-52 text-left">
          <div className={`flip-inner h-full ${flipped[i] ? "flipped" : ""}`}>
            <div className={`flip-face scrap-card flex flex-col items-center justify-center p-4 text-center ${colors[i]}`}>
              <span className="text-4xl" aria-hidden>🏅</span>
              <p className="mt-2 font-display font-bold leading-tight">{a.title}</p>
              <p className="mt-2 font-hand text-lg text-muted-foreground">tap me</p>
            </div>
            <div className="flip-face flip-back scrap-card flex items-center justify-center p-4 text-center">
              <p className="font-hand text-2xl leading-tight">{a.hidden}</p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}

type Mem = { title: string; body: string; img?: string | undefined };
const KEY = "amy-archives-memories";
function Memories() {
  const [items, setItems] = useState<Mem[]>(CONFIG.memories);
  useEffect(() => {
    try {
      const s = localStorage.getItem(KEY);
      if (!s) return;
      const saved: unknown = JSON.parse(s);
      if (!Array.isArray(saved)) return;
      const valid = saved.filter((m): m is Mem => typeof m === "object" && m !== null && typeof m.title === "string" && typeof m.body === "string");
      const next = valid.filter(keepScrapbookEntry);
      setItems(next);
      if (next.length !== valid.length) localStorage.setItem(KEY, JSON.stringify(next));
    } catch { /* ignore */ }
  }, []);
  const save = (next: Mem[]) => { setItems(next); try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { /* storage full */ } };
  const update = (i: number, patch: Partial<Mem>) => save(items.map((m, j) => (j === i ? { ...m, ...patch } : m)));
  const onFile = (i: number, f?: File) => {
    if (!f) return;
    const r = new FileReader();
    r.onload = () => update(i, { img: String(r.result) });
    r.readAsDataURL(f);
  };
  return (
    <>
      <p className="mb-4 font-hand text-xl text-muted-foreground">click any title or text to edit — it saves automatically on this device.</p>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((m, i) => (
          <article key={i} className="polaroid relative" style={{ transform: `rotate(${[-1.5, 1, -0.5, 1.5, -1][i] ?? 0}deg)` }}>
            <span className="tape -top-3 left-1/2 -translate-x-1/2 -rotate-2" />
            <div className="grid aspect-[4/3] place-items-center overflow-hidden border-2 border-dashed border-ink/30 bg-muted">
              {m.img ? <img src={m.img} alt={m.title} className="h-full w-full object-cover" /> : <span className="font-hand text-2xl text-muted-foreground">photo goes here ♡</span>}
            </div>
            <label className="mt-3 block font-display text-xs font-semibold">
              Title
              <input value={m.title} onChange={(e) => update(i, { title: e.target.value })} className="mt-1 w-full rounded-md border-2 border-ink/30 bg-transparent px-2 py-1 font-display text-base font-bold" />
            </label>
            <label className="mt-2 block font-display text-xs font-semibold">
              Description
              <textarea value={m.body} onChange={(e) => update(i, { body: e.target.value })} rows={3} className="mt-1 w-full rounded-md border-2 border-ink/30 bg-transparent px-2 py-1 font-hand text-xl leading-tight" />
            </label>
            <div className="mt-2 flex items-center gap-3 text-sm">
              <label className="cursor-pointer font-display underline">
                {m.img ? "change photo" : "add photo"}
                <input type="file" accept="image/*" className="sr-only" onChange={(e) => onFile(i, e.target.files?.[0])} />
              </label>
              {m.img && <button className="font-display underline" onClick={() => update(i, { img: undefined })}>remove</button>}
            </div>
          </article>
        ))}
      </div>
    </>
  );
}
