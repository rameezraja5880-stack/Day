import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CONFIG } from "@/config";
import catVideo from "@/assets/cat-meme-video.mp4";
import { Confetti, Doodles, Heading, Meme, Page, SectionTitle } from "@/components/scrap";

export const Route = createFileRoute("/letter")({
  head: () => ({
    meta: [
      { title: "One Last Thing, Amy — Zama Zargi" },
      { name: "description", content: "The last page: a birthday letter, 24 wishes, and a tiny cake for Amy." },
      { property: "og:title", content: "One Last Thing, Amy — Zama Zargi" },
      { property: "og:description", content: "The softest corner of the internet." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Letter,
});

function Letter() {
  return (
    <Page>
      <section className="relative">
        <Doodles count={10} seed={11} />
        <Heading title="THE LAST PAGE. THE SOFTEST CORNER OF THE INTERNET." />
      </section>
      <SectionTitle>Open your letter</SectionTitle>
      <Envelope />
      <SectionTitle note="tap each one">24 wishes for {CONFIG.name}</SectionTitle>
      <Wishes />
      <SectionTitle>Final meme reveal</SectionTitle>
      <FinalFile />
      <SectionTitle>The birthday finale</SectionTitle>
      <Finale />
    </Page>
  );
}

function Envelope() {
  const [open, setOpen] = useState(false);
  const [shown, setShown] = useState(0);
  const text = CONFIG.letter;
  useEffect(() => {
    if (!open) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { setShown(text.length); return; }
    const id = setInterval(() => setShown((s) => { if (s >= text.length) { clearInterval(id); return s; } return s + 2; }), 22);
    return () => clearInterval(id);
  }, [open, text]);
  const done = shown >= text.length;
  return (
    <div className="flex flex-col items-center">
      {!open ? (
        <button onClick={() => setOpen(true)} aria-label={`Open the letter for ${CONFIG.name}`} className="group relative h-52 w-80 transition hover:-rotate-2 sm:h-60 sm:w-96">
          <div className="absolute inset-0 rounded-lg border-2 border-ink bg-sky/70" style={{ boxShadow: "var(--shadow-sticker)" }} />
          <svg viewBox="0 0 100 60" preserveAspectRatio="none" className="absolute inset-0 h-full w-full" aria-hidden>
            <path d="M0 0 L50 36 L100 0" fill="var(--sky)" stroke="var(--ink)" strokeWidth="0.8" />
            <path d="M0 60 L40 30 M100 60 L60 30" stroke="var(--ink)" strokeWidth="0.6" fill="none" />
          </svg>
          <span className="absolute left-1/2 top-[52%] grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-ink bg-rose text-xl">♡</span>
          <span className="absolute bottom-3 left-0 right-0 text-center font-hand text-2xl">for {CONFIG.name}. open when ready.</span>
        </button>
      ) : (
        <article className="pop-in relative w-full max-w-2xl notebook scrap-card p-6 sm:p-10">
          <span className="tape -top-3 left-10 -rotate-6" />
          <span className="tape -top-3 right-10 rotate-6" />
          <span aria-hidden className="absolute -right-4 -top-6 text-4xl">🐈</span>
          <p className="whitespace-pre-wrap font-hand text-2xl leading-[28px]" aria-live="off">
            {text.slice(0, shown)}{!done && <span className="animate-pulse">▍</span>}
          </p>
          {!done && <button onClick={() => setShown(text.length)} className="mt-4 font-display text-sm underline">skip typing →</button>}
          <span className="sr-only">{text}</span>
        </article>
      )}
    </div>
  );
}

function Wishes() {
  const [open, setOpen] = useState<Set<number>>(new Set());
  const [active, setActive] = useState<number | null>(null);
  const colors = ["bg-butter", "bg-sky/70", "bg-sage/70", "bg-rose/60", "bg-lavender/70"];
  return (
    <div>
      <div className="grid grid-cols-4 gap-3 sm:grid-cols-6 lg:grid-cols-8">
        {CONFIG.wishes.map((_, i) => (
          <button key={i} onClick={() => { setActive(i); setOpen((s) => new Set(s).add(i)); }} aria-label={`Wish ${i + 1}${open.has(i) ? " (opened)" : ""}`}
            className={`aspect-square rounded-xl border-2 border-ink font-display text-xl font-bold transition hover:-translate-y-1 hover:rotate-3 ${open.has(i) ? "bg-card opacity-70" : colors[i % 5]}`}
            style={{ transform: `rotate(${((i * 7) % 9) - 4}deg)`, boxShadow: "var(--shadow-sticker)" }}>
            {open.has(i) ? "✓" : i + 1}
          </button>
        ))}
      </div>
      <div className="mt-6 min-h-24 text-center" aria-live="polite">
        {active !== null ? (
          <p key={active} className="pop-in bubble mx-auto inline-block max-w-xl bg-card text-2xl">
            <strong className="font-display text-base">#{active + 1}</strong> — {CONFIG.wishes[active]}
          </p>
        ) : <p className="font-hand text-2xl text-muted-foreground">pick a number ✦</p>}
        <p className="mt-2 text-sm text-muted-foreground">{open.size} / 24 opened{open.size === 24 && " — all wishes delivered 💜"}</p>
        {active !== null && (
          <figure className="pop-in mx-auto mt-6 max-w-sm">
            <video src={catVideo.url} controls autoPlay playsInline loop aria-label="Cat meme birthday video" className="aspect-square w-full rounded-lg border-2 border-ink bg-muted" />
            <figcaption className="mt-2 font-hand text-xl">wish received. the cat department is processing it.</figcaption>
          </figure>
        )}
      </div>
    </div>
  );
}

function FinalFile() {
  const [open, setOpen] = useState(false);
  return (
    <div className="grid items-center gap-8 md:grid-cols-2">
      <div className="flex flex-col items-center gap-4">
        <Meme kind="heart" size={170} rotate={-4} />
        <button className="btn-scrap" onClick={() => setOpen(true)} disabled={open}>OPEN THE FINAL FILE 📂</button>
      </div>
      <div aria-live="polite">
        {open ? (
          <div className="pop-in space-y-6">
            <pre className="scrap-card whitespace-pre-wrap bg-butter/40 p-5 font-mono text-sm leading-6">{CONFIG.finalReport}</pre>
            <Meme kind="sleepy" caption={CONFIG.captions.finalSleepy} size={170} rotate={3} bubbleSide="bottom" />
          </div>
        ) : <p className="text-center font-hand text-2xl text-muted-foreground">(file sealed. contents: suspiciously iconic.)</p>}
      </div>
    </div>
  );
}

function Finale() {
  const [run, setRun] = useState(0);
  const stars = Array.from({ length: 12 }, (_, i) => {
    const a = (i / 12) * Math.PI * 2;
    return { x: Math.cos(a) * 110, y: Math.sin(a) * 80, fx: Math.cos(a) * 400, fy: Math.sin(a) * 300 };
  });
  return (
    <div className="flex flex-col items-center pb-10">
      <Confetti fire={run} />
      {!run ? (
        <button className="btn-scrap text-xl" onClick={() => setRun(1)}>MAKE A WISH, {CONFIG.name.toUpperCase()} ✨</button>
      ) : (
        <div key={run} className="flex w-full flex-col items-center">
          <div className="relative grid h-64 w-72 place-items-center">
            {stars.map((s, i) => (
              <span key={i} aria-hidden className="gather absolute text-2xl" style={{ left: `calc(50% + ${s.x}px - 12px)`, top: `calc(50% + ${s.y}px - 14px)`, ["--x" as string]: `${s.fx}px`, ["--y" as string]: `${s.fy}px`, animationDelay: `${i * 0.05}s` }}>⭐</span>
            ))}
            <span className="pop-in font-display text-8xl font-bold" style={{ animationDelay: "0.6s" }}>{CONFIG.age}</span>
          </div>
          <Cake />
          <p className="pop-in mt-8 max-w-lg whitespace-pre-line rounded-3xl border-2 border-ink bg-card p-8 text-center font-hand text-3xl leading-snug" style={{ animationDelay: "1.4s", boxShadow: "var(--shadow-sticker)" }}>
            {CONFIG.finaleMessage}
          </p>
          <button className="btn-scrap mt-6" onClick={() => setRun((r) => r + 1)}>↻ replay the magic</button>
        </div>
      )}
    </div>
  );
}

function Cake() {
  return (
    <svg viewBox="0 0 200 170" className="pop-in w-64" style={{ animationDelay: "1s" }} role="img" aria-label="Birthday cake with cat ears and candles">
      <g stroke="var(--ink)" strokeWidth="2.5" strokeLinejoin="round">
        <rect x="30" y="100" width="140" height="50" rx="8" fill="var(--rose)" />
        <rect x="50" y="62" width="100" height="42" rx="8" fill="var(--butter)" />
        <path d="M58 64 L66 44 L76 62 M124 62 L134 44 L142 64" fill="var(--butter)" />
        <circle cx="86" cy="80" r="2.5" fill="var(--ink)" /><circle cx="114" cy="80" r="2.5" fill="var(--ink)" />
        <path d="M95 88 q5 5 10 0" fill="none" />
        <path d="M30 118 q14 10 28 0 t28 0 t28 0 t28 0 t28 0" fill="none" />
        <rect x="20" y="148" width="160" height="10" rx="5" fill="var(--sky)" />
        {[82, 100, 118].map((x) => (
          <g key={x}><rect x={x - 3} y="40" width="6" height="22" fill="var(--sky)" /><path className="flame" d={`M${x} 26 q6 8 0 13 q-6 -5 0 -13z`} fill="var(--butter)" style={{ transformBox: "fill-box" }} /></g>
        ))}
      </g>
      <text x="40" y="140" fontSize="14" aria-hidden>🐾</text>
      <text x="145" y="140" fontSize="14" aria-hidden>🐾</text>
    </svg>
  );
}
