import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { CONFIG, pick } from "@/config";
import { Confetti, Doodles, Heading, Meme, NextButton, Page, SectionTitle } from "@/components/scrap";
import { CatMemes } from "@/components/cat-memes";

export const Route = createFileRoute("/cats")({
  head: () => ({
    meta: [
      { title: "Cat.exe Has Stopped Working — Zama Zargi" },
      { name: "description", content: "Warning: extremely high cat content. A cat meme wall and summon-a-cat machine for Amy." },
      { property: "og:title", content: "Cat.exe Has Stopped Working — Zama Zargi" },
      { property: "og:description", content: "Warning: extremely high cat content." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Cats,
});

const C = CONFIG.images.cats;
const RARITY = [
  { tier: "Common", label: "a sleepy loaf", img: C.loaf, weight: 50, color: "bg-sage/60" },
  { tier: "Uncommon", label: "a dramatic orange cat", img: C.orange, weight: 30, color: "bg-butter" },
  { tier: "Rare", label: "a tiny astronaut cat", img: C.astronaut, weight: 15, color: "bg-sky" },
  { tier: "Legendary", label: "a cat sitting on Saturn", img: C.saturn, weight: 5, color: "bg-lavender" },
];
const WALL_IMGS = [C.loaf, C.orange, C.astronaut, C.saturn, C.orange, C.loaf];

function rollCat(prev?: string) {
  for (;;) {
    let r = Math.random() * 100;
    const c = RARITY.find((x) => (r -= x.weight) < 0) ?? RARITY[0]!;
    if (c.tier !== prev || Math.random() < 0.25) return c;
  }
}

function Cats() {
  const [cat, setCat] = useState<(typeof RARITY)[number] | null>(null);
  const [msg, setMsg] = useState("");
  const [rolls, setRolls] = useState(0);
  const [boom, setBoom] = useState(0);
  const [energy, setEnergy] = useState<string | null>(null);
  const [meows, setMeows] = useState<number[]>([]);
  const ac = useRef<AudioContext | null>(null);

  const summon = () => {
    const c = rollCat(cat?.tier);
    setCat(c); setMsg(pick(CONFIG.catMessages, msg)); setRolls((r) => r + 1);
    if (c.tier === "Legendary") setBoom((b) => b + 1);
  };
  const meow = () => {
    const id = Date.now();
    setMeows((m) => [...m.slice(-4), id]);
    setTimeout(() => setMeows((m) => m.filter((x) => x !== id)), 1600);
    try {
      ac.current = ac.current ?? new AudioContext();
      const c = ac.current, o = c.createOscillator(), g = c.createGain();
      o.type = "triangle";
      o.frequency.setValueAtTime(700, c.currentTime);
      o.frequency.linearRampToValueAtTime(1000, c.currentTime + 0.15);
      o.frequency.linearRampToValueAtTime(500, c.currentTime + 0.5);
      g.gain.setValueAtTime(0.0001, c.currentTime);
      g.gain.linearRampToValueAtTime(0.08, c.currentTime + 0.05);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 0.55);
      o.connect(g).connect(c.destination); o.start(); o.stop(c.currentTime + 0.6);
    } catch { /* sound is optional */ }
  };

  return (
    <Page>
      <Confetti fire={boom} />
      <section className="relative">
        <Doodles count={16} seed={5} />
        <Heading kicker="⚠ SYSTEM ALERT ⚠" title="WARNING: EXTREMELY HIGH CAT CONTENT." sub="Welcome to the scientifically unnecessary cat department." />
      </section>

      <SectionTitle note="peer-reviewed by cats">The cat meme wall</SectionTitle>
      <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
        <div className="scrap-card break-inside-avoid bg-rose/30 p-4"><Meme kind="heart" caption={CONFIG.captions.catHeart} size={170} /></div>
        {CONFIG.catWall.map((cap, i) => (
          <figure key={i} className="polaroid relative break-inside-avoid" style={{ transform: `rotate(${[-2, 1.5, -1, 2, -1.5, 1][i]}deg)` }}>
            <span className="tape -top-3 left-1/2 -translate-x-1/2 rotate-2" />
            <img src={WALL_IMGS[i]} alt="Hand-drawn cat sticker" loading="lazy" width={816} height={816} className="w-full bg-muted" />
            <figcaption className="mt-2 text-center font-hand text-2xl leading-tight">{cap}</figcaption>
          </figure>
        ))}
        <div className="scrap-card break-inside-avoid bg-sky/30 p-4"><Meme kind="sleepy" caption={CONFIG.captions.catSleepy} size={160} rotate={-2} /></div>
      </div>

      <SectionTitle note="certified cat chaos">The real cat memes</SectionTitle>
      <CatMemes />

      <SectionTitle note="gacha, but wholesome">Summon a cat</SectionTitle>
      <div className="grid gap-6 md:grid-cols-[1fr_1.3fr]">
        <div className="scrap-card p-6">
          <button className="btn-scrap" onClick={summon}>SUMMON RANDOM CAT 🐾</button>
          <ul className="mt-5 space-y-2 text-sm">
            {RARITY.map((r) => (
              <li key={r.tier} className="flex items-center gap-2"><span className={`rounded-full border-2 border-ink px-2 py-0.5 font-display text-xs font-bold ${r.color}`}>{r.tier}</span> {r.label}</li>
            ))}
          </ul>
          <p className="mt-3 font-hand text-lg text-muted-foreground">rarity is entirely made up. all cats are legendary in spirit.</p>
          <p className="mt-1 text-xs text-muted-foreground">cats summoned: {rolls}</p>
        </div>
        <div className="scrap-card grid min-h-80 place-items-center bg-butter/30 p-6 text-center" aria-live="polite">
          {cat ? (
            <div key={rolls} className="pop-in">
              <span className={`rounded-full border-2 border-ink px-3 py-1 font-display text-sm font-bold ${cat.color}`}>{cat.tier.toUpperCase()}{cat.tier === "Legendary" && " ✨"}</span>
              <img src={cat.img} alt={cat.label} width={816} height={816} className="mx-auto mt-3 w-52" />
              <p className="font-hand text-2xl">{msg}</p>
            </div>
          ) : <p className="font-hand text-2xl text-muted-foreground">(no cat yet. the void meows softly.)</p>}
        </div>
      </div>

      <SectionTitle note="not a real assessment, obviously">The cat personality machine</SectionTitle>
      <div className="scrap-card mx-auto max-w-2xl bg-sage/30 p-8 text-center">
        <button className="btn-scrap" onClick={() => setEnergy((e) => pick(CONFIG.catEnergy, e ?? undefined))}>DIAGNOSE MY CAT ENERGY</button>
        <p key={energy} aria-live="polite" className={`mt-6 min-h-12 font-hand text-3xl ${energy ? "pop-in" : "text-muted-foreground"}`}>{energy ?? "(insert human to begin)"}</p>
      </div>

      <SectionTitle>Paw-some birthday message</SectionTitle>
      <div className="relative flex flex-col items-center gap-6 py-6">
        <p className="-rotate-2 rounded-[30px] border-2 border-dashed border-ink bg-rose/40 px-6 py-4 text-center font-display text-xl font-bold sm:text-2xl">
          {CONFIG.name.toUpperCase()} + CATS = A VERY SERIOUS SCIENTIFIC RELATIONSHIP.
        </p>
        <div className="relative">
          <button className="btn-scrap" onClick={meow}>MEOW FOR NO REASON 🐱</button>
          {meows.map((id, i) => (
            <span key={id} aria-hidden className="pop-in bubble pointer-events-none absolute -top-14 whitespace-nowrap" style={{ left: `${-40 + i * 40}px` }}>meow{"!".repeat(1 + (i % 3))} 🐾</span>
          ))}
        </div>
        <span className="sr-only" aria-live="polite">{meows.length ? "meow!" : ""}</span>
      </div>

      <NextButton to="/twins">OKAY, NOW LET'S INVESTIGATE OUR FRIENDSHIP →</NextButton>
    </Page>
  );
}
