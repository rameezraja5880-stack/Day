import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "node:path";
// Asset imports return an object with `.url` (same shape the original project used).
const assetUrl = () => ({
  name: "asset-url", enforce: "pre",
  resolveId(id, importer) {
    if (/\.(png|jpe?g|webm|mp4)$/.test(id)) return this.resolve(id + "?asset-wrap", importer, { skipSelf: true });
  },
  load(id) {
    if (id.endsWith("?asset-wrap")) {
      const real = id.replace("?asset-wrap", "");
      return `import u from ${JSON.stringify(real + "?url")};const o=Object.assign(new String(u),{url:u});export default o;`;
    }
  },
});
export default defineConfig({
  base: "./",
  plugins: [assetUrl(), react(), tailwindcss()],
  resolve: { alias: { "@": path.resolve("./src") } },
  assetsInlineLimit: 0,
});
